@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="" method="post">
            				<h3>LOAN AGAINST PROPERTY(LAP)
                                FOR SALARIED PERSON</h3>
            				<!-- Input fields -->

                            <div class="form-group">
                                <label for="pan" style="color:black;">APPLICANT KYC PAPER - Pan Card:</label>
                                <input type="file" class="form-control" name="pan"/>
                        </div>
                        <div class="form-group">
                                <label for="aadhar" style="color:black;">APPLICANT KYC PAPER - Aadhar Card:</label>
                                <input type="file" class="form-control" name="aadhar"/>
                        </div>
                        <div class="form-group">
                                <label for="photo" style="color:black;">APPLICANT KYC PAPER - Photo:</label>
                                <input type="file" class="form-control" name="photo"/>
                        </div>
                        <div class="form-group">
                                <label for="sal_slip" style="color:black;">3 MONTH LATEST SALARY SLIP:</label>
                                <input type="file" class="form-control" name="sal_slip">
                        </div>
                        <div class="form-group">
                                <label for="bank_statement" style="color:black;">6 MONTH BANK STATEMENT UPDATED :</label>
                                <input type="file" class="form-control" name="bank_statement">
                        </div>
                        <div class="form-group">
                                <label for="form16" style="color:black;">FORM 16/26AS :</label>
                                <input type="file" class="form-control" name="form16">
                        </div>
                        <div class="form-group">
                                <label for="rad" style="color:black;">RESIDENCIAL ADDRESS PROOF:</label>
                                <input type="file" class="form-control" name="rad">
                        </div>
                        <div class="form-group">
                                <label for="sal_proof" style="color:black;">SALARY PROOF( FOR NON-GOVT SALARIED PERSON):</label>
                                <input type="file" class="form-control" name="sal_proof">
                        </div>
                        <div class="form-group">
                                <label for="ca_pan" style="color:black;">CO-APPLICANT KYC PAPER - PAN CARD:</label>
                                <input type="file" class="form-control" name="ca_pan">
                        </div>
                        <div class="form-group">
                                <label for="aadhar" style="color:black;">CO-APPLICANT KYC PAPER - AADHAR CARD:</label>
                                <input type="file" class="form-control" name="ca_aadhar">
                        </div>
                        <div class="form-group">
                                <label for="photo" style="color:black;">CO-APPLICANT KYC PAPER - PHOTO:</label>
                                <input type="file" class="form-control" name="ca_photo">
                        </div>
                        <div class="form-group">
                                <label for="property_paper" style="color:black;">PROPERTY PAPER WITH ALL  CHAIN DEED:</label>
                                <input type="file" class="form-control" name="property_paper">
                        </div>
                        <div class="form-group">
                                <label for="ats" style="color:black;">AGREEMENT TO SALE(ATS):</label>
                                <input type="file" class="form-control" name="ats">
                        </div>



            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Upload
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection
