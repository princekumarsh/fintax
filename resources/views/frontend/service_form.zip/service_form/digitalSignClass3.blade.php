@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="{{route('service.digitalSignClass3Post')}}" method="post" enctype="multipart/form-data">
                                @csrf
            				<h3>DIGITAL SIGNATURE CERTIFICATE CLASS-3  &nbsp;&nbsp;RS 1049/-</h3>
            				<!-- Input fields -->
                                        <input type="hidden" name="reg_type" value="digital_signature3">
                                         <div class="form-group">
                                <label for="name" style="color:black;">NAME:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="name" placeholder="Enter your name" />
                                <div class="text-danger">
                                    @error('name')
                                    <span >{{$message}}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" style="color:black;">MOBILE:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="mobile" placeholder="Enter your mobile no."/>
                                <div class="text-danger">
                                     @error('mobile')
                                     <span >{{$message}}</span>
                                     @enderror
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" style="color:black;">EMAIL:<span class="asterisk">*</span></label>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email"/>
                                <div class="text-danger">
                                 @error('email')
                                 <span >{{$message}}</span>
                                 @enderror
                                </div>
                            </div>
                            <hr>
                                        <h3 class="text-danger">&#129155 Optional Documents</h3>

                                        <div class="form-group">
                                                <label for="pan" style="color:black;">Pan Card:</label>
                                                <input type="file" class="form-control" name="pan_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="aadhar" style="color:black;">Aadhar Card:</label>
                                                <input type="file" class="form-control" name="aadhar_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="photo" style="color:black;">Photo:</label>
                                                <input type="file" class="form-control" name="photo"/>
                                        </div>




            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Upload
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection
