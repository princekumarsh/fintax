@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">	
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="{{route('service.itr_professionalsPost')}}" method="post" enctype="multipart/form-data">
                                @csrf
            				<h3>PROFESSIONALS (Rate RS 999/-)</h3>
            				<!-- Input fields -->
                                        <input type="hidden" value="professionals" name="itr">
                                        <div class="form-group">
                                                <label for="name" style="color:black;">NAME:<span class="asterisk">*</span></label>
                                                <input type="text" class="form-control" name="name" placeholder="Enter your name" />
                                                <div class="text-danger">
                                                 @error('name')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="mobile" style="color:black;">MOBILE:<span class="asterisk">*</span></label>
                                                <input type="text" class="form-control" name="mobile" placeholder="Enter your mobile no."/>
                                                <div class="text-danger">
                                                 @error('mobile')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="email" style="color:black;">EMAIL:<span class="asterisk">*</span></label>
                                                <input type="email" class="form-control" name="email" placeholder="Enter your email"/>
                                                <div class="text-danger">
                                                 @error('email')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="pan" style="color:black;">Pan Card:</label>
                                                <input type="file" class="form-control" name="pan_card"/>
                                                 <div class="text-danger">
                                                 @error('pan_card')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="aadhar" style="color:black;">Aadhar Card:</label>
                                                <input type="file" class="form-control" name="aadhar_card"/>
                                                 <div class="text-danger">
                                                 @error('aadhar_card')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <hr>
                                        <h3 class="text-danger">&#129155 Optional Documents</h3>
            				
                                        <div class="form-group">
                                                <label for="brp" style="color:black;">
                                               BUSINESS ADDRESS PROOF/PROFESSIONAL REGISTRATION PROOF:</label>
                                                <input type="file" class="form-control" name="prp"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="aybs" style="color:black;">
                                               ASSESSMENT YEAR BANK STATEMENT:</label>
                                                <input type="file" class="form-control" name="aybs"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="assementyearreturn" style="color:black;">
                                                ASSESSMENT YEAR GSTR-3B RETURN (IF YOU ARE A GSTIN PERSON):</label>
                                                <input type="file" class="form-control" name="ayr"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="assementyearturnover" style="color:black;">
                                               ASSESSMENT YEAR BUSINESS TURN OVER DETAILS( IF YOU ARE NOT REGISTRED PERSON):</label>
                                                <input type="file" class="form-control" name="aybto"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="investmentproof" style="color:black;">
                                               INVESTMENT PROOF IF ANY:</label>
                                                <input type="file" class="form-control" name="investment_proof"/>
                                        </div>

        
            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Upload
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection