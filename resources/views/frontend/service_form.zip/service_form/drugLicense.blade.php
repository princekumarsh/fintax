@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="{{route('service.drugLicensePost')}}" method="post">
                            @csrf
            				<h3>DRUG LICENSE REGISTRATION</h3>
            				<!-- Input fields -->
                            <input type="hidden" name="reg_type" value="drug_licence">
                            <div class="form-group">
                                <label for="name" style="color:black;">NAME:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="name" placeholder="Enter your name" />
                            </div>
                            <div class="form-group">
                                <label for="mobile" style="color:black;">MOBILE:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="mobile" placeholder="Enter your mobile no." />
                            </div>
                            <div class="form-group">
                                <label for="email" style="color:black;">EMAIL:<span class="asterisk">*</span></label>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email" />
                            </div>
            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Submit
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>
@endsection
