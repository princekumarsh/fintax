@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="" method="post">
            				<h3>CREDIT CARD
                                FOR BUSINESS MAN </h3>
            				<!-- Input fields -->

                                        <div class="form-group">
                                                <label for="pan" style="color:black;">Pan Card:</label>
                                                <input type="file" class="form-control" name="pan"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="aadhar" style="color:black;">Aadhar Card:</label>
                                                <input type="file" class="form-control" name="aadhar"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="photo" style="color:black;">Photo:</label>
                                                <input type="file" class="form-control" name="photo"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="gst" style="color:black;">GST Certificate:</label>
                                                <input type="file" class="form-control" name="gst">
                                        </div>




            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Upload
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection
