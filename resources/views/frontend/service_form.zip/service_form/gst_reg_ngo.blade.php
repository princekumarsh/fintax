@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">	
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="{{route('service.gst_reg_ngoPost')}}" method="post" enctype="multipart/form-data">
                                @csrf
            				<h3>NGO/SOCIETY/TRUST/ SECTON 8 (Rate RS 1499/-)</h3>
            				<!-- Input fields -->
                                        <div class="form-group">
                                                <label for="name" style="color:black;">NAME:<span class="asterisk">*</span></label>
                                                <input type="text" class="form-control" name="name" placeholder="Enter your name" />
                                                <div class="text-danger">
                                                 @error('name')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="mobile" style="color:black;">MOBILE:<span class="asterisk">*</span></label>
                                                <input type="text" class="form-control" name="mobile" placeholder="Enter your mobile no."/>
                                                <div class="text-danger">
                                                 @error('mobile')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <div class="form-group">
                                                <label for="email" style="color:black;">EMAIL:<span class="asterisk">*</span></label>
                                                <input type="email" class="form-control" name="email" placeholder="Enter your email"/>
                                                <div class="text-danger">
                                                 @error('email')
                                                 <span >{{$message}}</span>
                                                 @enderror
                                                </div>
                                        </div>
                                        <hr>
                                        <h3 class="text-danger">&#129155 Optional Documents</h3>
            			
            				<div class="form-group">
              					<label for="ngo" style="color:black;">PAN CARD OF NGO/SOCIETY/TRUST/SECTION 8 COMPANY:</label>
              					<input type="file" class="form-control" name="ngo_pan_card"/>
            				</div>
                                        <div class="form-group">
                                                <label for="certificate" style="color:black;">CERTIFICATE :</label>
                                                <input type="file" class="form-control" name="certificate"/>
                                        </div>
            				<div class="form-group">
              					<label for="moa" style="color:black;">
              					MOA & AOA:</label>
              					<input type="file" class="form-control" name="moa"/>
            				</div><hr/>
            				<div class="form-group">
              					<label for="kyc" style="color:black;">ANY ONE AUTHORIZED PERSON'S KYC PAPER( PAN CARD, ADHAR CARD, PHOTO):</label>
            				</div>
                                        <div class="form-group">
                                                <label for="kycpan" style="color:black;">Pan Card:</label>
                                                <input type="file" class="form-control" name="autho_pan_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="kycaadhar" style="color:black;">Aadhar Card:</label>
                                                <input type="file" class="form-control" name="autho_aadhar_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="kycphoto" style="color:black;">
                                                Photo:</label>
                                                <input type="file" class="form-control" name="autho_photo"/>
                                        </div><hr/>

                                        <div class="form-group">
                                                <label for="authorization" style="color:black;">AUTHORIZATION LETTER FOR AUTHORIZED SIGNATORY:</label>
                                                <input type="file" class="form-control" name="autho_letter"/>
                                        </div>

                                        <div class="form-group">
                                                <label for="bap" style="color:black;">BUSINESS ADDRESS PROFF( ELECTRICITY BILL, RENT AGREEMENT IF RENTED, NOC PAPER IF SHARED & ANOTHER LEGAL OWNERSHIP PROOF):</label>
                                                <input type="file" class="form-control" name="autho_bap"/>
                                        </div>
            				
        
            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Upload
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection