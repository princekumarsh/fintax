@extends('layout.frontend.app')
@section('content')

<!-- Main content Start -->
        <div class="main-content">
        	<div>
      			<div class="row">
        			<div class="mx-auto col-10 col-md-8 col-lg-6">
                    	<!-- Form -->
                    	<form class="form-example" action="{{route('service.companyRegisterationNidhiPost')}}" method="post" enctype="multipart/form-data">
                            @csrf
            				<h3>COMPANY REGISTERATION FOR NIDHI COMPANY  (Rate RS 14999/ + GOV FEE-) UP TO 10 LAC CAPITAL SHARE</h3>
            				<!-- Input fields -->
                            <input type="hidden" name="com_type" value="nidhi_com">
                            <div class="form-group">
                                <label for="name" style="color:black;">NAME:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="name" placeholder="Enter your name" />
                                <div class="text-danger">
                                    @error('name')
                                    <span >{{$message}}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" style="color:black;">MOBILE:<span class="asterisk">*</span></label>
                                <input type="text" class="form-control" name="mobile" placeholder="Enter your mobile no."/>
                                <div class="text-danger">
                                     @error('mobile')
                                     <span >{{$message}}</span>
                                     @enderror
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" style="color:black;">EMAIL:<span class="asterisk">*</span></label>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email"/>
                                <div class="text-danger">
                                 @error('email')
                                 <span >{{$message}}</span>
                                 @enderror
                                </div>
                            </div>
                            <hr>
                                        <h3 class="text-danger">&#129155 Optional Documents</h3>

                                        <div class="form-group">
                                                <label for="pan" style="color:black;">KYC PAPER OF ALL DIRECTORS  </label>
                                                <label for="pan" style="color:black;">- Pan Card:</label>
                                                <input type="file" class="form-control" name="kyc_pan_card"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="pan" style="color:black;">KYC PAPER OF ALL DIRECTORS  </label>
                                                <label for="aadhar" style="color:black;">- Aadhar Card:</label>
                                                <input type="file" class="form-control" name="kyc_aadhar_card"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="photo" style="color:black;">KYC PAPER OF ALL DIRECTORS  </label>
                                                <label for="photo" style="color:black;">- Photo:</label>
                                                <input type="file" class="form-control" name="kyc_photo"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="bank_statement" style="color:black;">KYC PAPER OF ALL DIRECTORS  </label>
                                                <label for="bank_statement" style="color:black;">- 6 Month Bank Statement:</label>
                                                <input type="file" class="form-control" name="kyc_bank_statement"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="ebill" style="color:black;">BUSINESS ADDRESS PROFF( ELECTRICITY BILL/ RENT AGREEMENT IF RENTED/ NOC PAPER IF SHARED & ANOTHER LEGAL OWNERSHIP PROOF)</label>
                                                <input type="file" class="form-control" name="bap"/>
                                        </div>
                                        
                                        <div class="form-group">
                                                <label for="signature" style="color:black;">DIGITAL SIGNATURE OF ALL DIRECTOR'S:</label>
                                                <input type="file" class="form-control" name="signature"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="bank_dtl" style="color:black;">
                                                    BANK DETAILS( CANCELLED CHEQUE/ BANK PASSBOOK FRONT PAGE):</label>
                                                <input type="file" class="form-control" name="bank_details"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="memeber_kyc" style="color:black;">
                                                    7 MEMBER KYC PAPER'S( PAN CARD):</label>
                                                <input type="file" class="form-control" name="memeber7_pan_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="memeber_kyc" style="color:black;">
                                                    7 MEMBER KYC PAPER'S( ADHAR CARD):</label>
                                                <input type="file" class="form-control" name="memeber7_aadhar_card"/>
                                        </div>
                                        <div class="form-group">
                                                <label for="memeber_kyc" style="color:black;">
                                                    7 MEMBER KYC PAPER'S( PHOTO):</label>
                                                <input type="file" class="form-control" name="memeber7_photo"/>
                                        </div>

            				<button type="submit" class="btn btn-danger btn-customized mt-2 mb-2">
              				Submit
            				</button>
          				</form>
          				<!-- Form end -->
        			</div>
      			</div>
    		</div>
        </div>

@endsection
