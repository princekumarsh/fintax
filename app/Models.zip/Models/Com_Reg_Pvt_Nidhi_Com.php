<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Com_Reg_Pvt_Nidhi_Com extends Model
{
    use HasFactory;
}
