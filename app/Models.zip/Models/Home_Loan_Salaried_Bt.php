<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Home_Loan_Salaried_Bt extends Model
{
    use HasFactory;
}
