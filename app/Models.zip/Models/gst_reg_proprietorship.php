<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class gst_reg_proprietorship extends Model
{
    use HasFactory;
    public $table = "gst_reg_proprietorship";
}
